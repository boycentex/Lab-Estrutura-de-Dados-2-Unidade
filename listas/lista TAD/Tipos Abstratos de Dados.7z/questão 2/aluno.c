#include "aluno.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Aluno *criar_aluno(char* nome, int matricula) {
    Aluno *novo = (Aluno*) malloc(sizeof(Aluno));
    if (novo == NULL) {
        printf("Erro na alocação de memória.\n");
        exit(1);
    }
    strcpy(novo->nome, nome);
    novo->matricula = matricula;
    novo->num_disciplinas = 0;
    return novo;
}

void matricular_aluno(Aluno* aluno, Disciplina* disciplina) {
    if (aluno == NULL || disciplina == NULL) {
        printf("Erro: Aluno ou disciplina não criados.\n");
        return;
    }
    int i;
    for (i = 0; i < aluno->num_disciplinas; i++) {
        if (aluno->disciplinas[i]->codigo == disciplina->codigo) {
            printf("Erro: Aluno já está matriculado nesta disciplina.\n");
            return;
        }
    }
    if (aluno->num_disciplinas < 10) {
        aluno->disciplinas[aluno->num_disciplinas] = disciplina;
        aluno->num_disciplinas++;
        printf("Aluno matriculado.\n");
    } else {
        printf("Erro: O aluno já está matriculado no número máximo de disciplinas.\n");
    }
}

void excluir_aluno(Aluno* aluno) {
    if (aluno == NULL) {
        printf("Nenhum aluno para excluir.\n");
        return;
    }
    free(aluno);
    printf("Aluno removido.\n");
}