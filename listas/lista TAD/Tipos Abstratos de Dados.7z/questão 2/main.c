#include <stdio.h>
#include<locale.h> 
#include "disciplina.h"
#include "aluno.h"


void menu() {
    printf("\nEscolha uma opção:\n");
    printf("1. Criar Disciplina\n");
    printf("2. Criar Aluno\n");
    printf("3. Matricular Aluno em Disciplina\n");
    printf("4. Excluir Disciplina\n");
    printf("5. Excluir Aluno\n");
    printf("0. Sair\n");
}

int main() {
    setlocale(LC_ALL, "portuguese");
    
    Aluno *aluno = NULL;
    Disciplina *disciplina = NULL;
    int opcao;
    char nome[100];
    int codigo;
    int matricula;

    do {
        menu();
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("Informe o nome da disciplina:\n");
                scanf("%s", nome);
                printf("Informe o código da disciplina:\n");
                scanf("%d", &codigo);
                disciplina = cria_disciplina(nome, codigo);
                break;
            case 2:
                printf("Informe o nome do aluno:\n");
                scanf("%s", nome);
                printf("Informe a matrícula do aluno:\n");
                scanf("%d", &matricula);
                aluno = criar_aluno(nome, matricula);
                break;
            case 3:
                if (aluno != NULL && disciplina != NULL) {
                    matricular_aluno(aluno, disciplina);
                } else {
                    printf("Erro: Aluno ou disciplina não criados.\n");
                }
                break;
            case 4:
                if (disciplina != NULL) {
                    excluir_disciplina(disciplina);
                    disciplina = NULL;
                } else {
                    printf("Erro: Nenhuma disciplina para excluir.\n");
                }
                break;
            case 5:
                if (aluno != NULL) {
                    excluir_aluno(aluno);
                    aluno = NULL;
                } else {
                    printf("Erro: Nenhum aluno para excluir.\n");
                }
                break;
            case 0:
                printf("Encerrando programa.\n");
                break;
            default:
                printf("Opção inválida.\n");
                break;
        }
    } while (opcao != 0);

    return 0;
}