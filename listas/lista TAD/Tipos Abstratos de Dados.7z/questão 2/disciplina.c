#include "disciplina.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Disciplina *cria_disciplina(char* nome, int codigo) {
    Disciplina *nova = (Disciplina*) malloc(sizeof(Disciplina));
    if (nova == NULL) {
        printf("Erro na alocação de memória.\n");
        exit(1);
    }
    strcpy(nova->nome, nome);
    nova->codigo = codigo;
    return nova;
}

void excluir_disciplina(Disciplina *disciplina) {
    if (disciplina == NULL) {
        printf("Nenhuma disciplina para excluir.\n");
        return;
    }
    free(disciplina);
    printf("Disciplina removida.\n");
    
}