#ifndef CONTABANCARIA_H
#define CONTABANCARIA_H

typedef struct { 
    char titular[50];
    int numero;
    float saldo;
} CB;

CB *criar_conta(char *nome, int numero, float saldo);
void Deposita(CB *conta, float valor);
void Sacar(CB *conta, float valor);
void Transferir(CB *ContaOrigem, CB *ContaDestino, float valor);
float Saldo(CB *conta);
void Excluir_conta(CB *conta);

#endif
