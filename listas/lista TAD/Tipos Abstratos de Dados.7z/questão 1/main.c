#include <stdio.h>
#include <locale.h>
#include<stdlib.h>
#include<string.h>
#include "contabancaria.h"

void menu() { 
    printf("\nEscolha uma das opções:\n");
    printf("1 - Criar Conta Bancária\n");
    printf("2 - Depositar\n");
    printf("3 - Sacar\n");
    printf("4 - Transferir\n");
    printf("5 - Meu Atual Saldo\n");
    printf("6 - Excluir Conta\n");
    printf("0 - Encerrar\n");
}

int main() {
    setlocale(LC_ALL, "portuguese");

    CB *p = NULL;
    int opcao;

    do {
        menu();
        printf("Opção: ");
        scanf("%d", &opcao);
        
        if (opcao == 1) {
            char nome[50];
            int numero;
            float saldo;
            
            printf("\nOpção: Criar Conta\n");
            printf("Informe o nome do titular da conta: ");
            scanf(" %[^\n]", nome);
            printf("Informe o número da conta: ");
            scanf("%d", &numero);
            printf("Informe o saldo inicial da conta: ");
            scanf("%f", &saldo);
            
            p = criar_conta(nome, numero, saldo);
            printf("Conta criada com sucesso!\n");

        } else if (opcao == 2) {
            float valor;
            printf("\nOpção: Depositar\n");
            printf("Informe o valor que deseja depositar: ");
            scanf("%f", &valor);
            
            if (p != NULL) {
                Deposita(p, valor);
                printf("Valor depositado com sucesso!\n");
            } else {
                printf("Erro: Nenhuma conta existente. Crie uma conta primeiro.\n");
            }

        } else if (opcao == 3) {
            float valor;
            printf("\nOpção: Sacar\n");
            printf("Informe o valor que deseja sacar: ");
            scanf("%f", &valor);
            
            if (p != NULL) {
                Sacar(p, valor);
            } else {
                printf("Erro: Nenhuma conta existente. Crie uma conta primeiro.\n");
            }

        } else if (opcao == 4) {
            CB *n = NULL;
            char nome[50];
            int numero;
            float valor;

            printf("\nOpção: Transferir\n");
            printf("Informe o nome do titular da conta de destino: ");
            scanf(" %[^\n]", nome);
            printf("Informe o número da conta de destino: ");
            scanf("%d", &numero);
            printf("Informe o valor que deseja transferir: ");
            scanf("%f", &valor);

            n = criar_conta(nome, numero, 0);  // Cria uma conta temporária de destino sem saldo
            
            if (p != NULL && n != NULL) {
                Transferir(p, n, valor);
            } else {
                printf("Erro: Nenhuma conta existente. Crie uma conta primeiro.\n");
            }
            Excluir_conta(n);  // Libera a conta temporária de destino

        } else if (opcao == 5) {
            printf("\nOpção: Meu Atual Saldo\n");
            
            if (p != NULL) {
                printf("Saldo Atual: %.2f\n", Saldo(p));
            } else {
                printf("Erro: Nenhuma conta existente. Crie uma conta primeiro.\n");
            }

        } else if (opcao == 6) {
            printf("\nOpção: Excluir Conta\n");
            
            if (p != NULL) {
                Excluir_conta(p);
                p = NULL;
                printf("Conta excluída com sucesso!\n");
            } else {
                printf("Erro: Nenhuma conta existente para excluir.\n");
            }

        } else if (opcao != 0) {
            printf("Opção inválida. Tente novamente.\n");
        }
        
    } while (opcao != 0);

    printf("Encerrando o programa...\n");
    return 0;
}
