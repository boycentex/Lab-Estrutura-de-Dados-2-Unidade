#ifndef ALUNO_H
#define ALUNO_H

#include "disciplina.h"

typedef struct {
    char nome[100];
    int matricula;
    Disciplina* disciplinas[10];
    int num_disciplinas;
} Aluno;

Aluno *criar_aluno(char* nome, int matricula);
void matricular_aluno(Aluno* aluno, Disciplina* disciplina);
void excluir_aluno(Aluno* aluno);

#endif