#include "contabancaria.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

CB *criar_conta(char *nome, int numero, float saldo) {
    CB *novaconta = (CB*) malloc(sizeof(CB));    
    if (novaconta == NULL) {
        printf("Erro na alocação de memória.\n");
        exit(1);
    }
    strcpy(novaconta->titular, nome);
    novaconta->numero = numero;
    novaconta->saldo = saldo;
    return novaconta;
}

void Deposita(CB *conta, float valor) { 
    if (conta != NULL && valor > 0) { 
        conta->saldo += valor;
    }
}

void Sacar(CB *conta, float valor) { 
    if (conta != NULL && valor > 0) {
        if (conta->saldo >= valor) { 
            conta->saldo -= valor;
            printf("Saque realizado com sucesso. Novo saldo: %.2f\n", conta->saldo);
        } else {
            printf("Saldo insuficiente para realizar o saque.\n");
        }
    }   
}

void Transferir(CB *ContaOrigem, CB *ContaDestino, float valor) {
    if (ContaOrigem != NULL && ContaDestino != NULL && valor > 0) {
        if (ContaOrigem->saldo >= valor) {
            ContaOrigem->saldo -= valor;
            ContaDestino->saldo += valor;
            printf("Transferência de %.2f realizada com sucesso.\n", valor);
        } else {
            printf("Saldo insuficiente para realizar a transferência de %.2f.\n", valor);
        }
    }
}

float Saldo(CB *conta) { 
    if (conta != NULL) { 
        return conta->saldo;
    }
}

void Excluir_conta(CB *conta) {
    if (conta != NULL) {
        free(conta);
        printf("Conta excluída.\n");
    }
}


